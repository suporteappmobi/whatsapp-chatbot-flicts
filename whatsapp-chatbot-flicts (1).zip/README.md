
# WhatsApp Chatbot - Flicts

### Como usar:
1. Suba este repositório para o GitHub.
2. No Render → New Web Service → conectar ao repositório.
3. Configure:
   - Build Command: npm install
   - Start Command: npm start
4. Criar variáveis de ambiente:
   - VERIFY_TOKEN
   - ACCESS_TOKEN
   - PHONE_NUMBER_ID
   - ATTENDANT_NAME
   - ATTENDANT_PHOTO
   - TARGET_NUMBER

